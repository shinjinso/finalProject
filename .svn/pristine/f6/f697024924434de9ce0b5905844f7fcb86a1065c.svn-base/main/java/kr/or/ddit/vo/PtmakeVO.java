package kr.or.ddit.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PtmakeVO {	
	private int ptsNo;
	private String ptNo;
	private String ddCode;
	private String pyCode;
	private int pddAmt;
	private int ppyAmt;
}
