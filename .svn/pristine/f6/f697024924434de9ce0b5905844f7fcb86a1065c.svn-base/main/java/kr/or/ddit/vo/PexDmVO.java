package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PexDmVO {
	private String dftNo;
	private String pexCont;
	private String pexRsn;
	private Date pexDate;
	private int pexAmt;
}
