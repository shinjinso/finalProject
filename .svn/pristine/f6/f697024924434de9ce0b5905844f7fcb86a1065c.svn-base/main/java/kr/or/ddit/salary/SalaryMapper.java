package kr.or.ddit.salary;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SalaryMapper {

}
