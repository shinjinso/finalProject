package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class VacHoldVO {
	private int vhCngNo;
	private String vhNm;
	private String vhInfo;
	private int vhDaycnt;
	private Date vhUseDate;
	private Date vhEndDate;
}
