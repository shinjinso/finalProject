package kr.or.ddit.salary.service;

public interface SalaryService {

}
