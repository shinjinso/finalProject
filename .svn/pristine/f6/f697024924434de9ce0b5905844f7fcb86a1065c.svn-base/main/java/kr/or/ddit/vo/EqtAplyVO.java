package kr.or.ddit.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EqtAplyVO {
	private String dftNo;
	private String eqtNm;
	private String eqtInfo;
	private int qtt;
	private int price;
	private int amt;
	private String eqtRsn;
}
