	package kr.or.ddit.vo;

import lombok.Data;

@Data
public class DatasetsVO {
	private String label = "Visitors";
    private String barThickness = "10";
    private String backgroundColor = "green";
    private String borderColor = "green";
    private String pointRadius = "!1";
    private String pointColor = "#3b8bba";
    private String pointStrokeColor = "rgba(60,141,188,1)";
    private String pointHighlightFill = "#fff";
    private String pointHighlightStroke = "rgba(60,141,188,1)";
    private int[] data = {11, 48, 40, 19, 64, 27, 90, 85, 92};
    private String fill = "";
    private String lineTension = ".1";
}
