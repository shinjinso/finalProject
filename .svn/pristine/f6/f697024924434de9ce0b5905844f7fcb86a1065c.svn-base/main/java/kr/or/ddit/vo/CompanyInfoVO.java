package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CompanyInfoVO {
	private int coNo;
	private String coNm;
	private String coRep;
	private String coTelno;
	private Date coEstdDate;
	private String coAddr;
	private int coNmpr;
	private String coInt;
	private String coRegno;
	private String corRegno;
	private String coTax;
	private String fileNo;
}
