package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DocWriVO {
	private String dftNo;
	private String empNo;
	private String docTitle;
	private String docAbst;
	private Date dftDate;
	private String lpermSt;
	private Date udtDate;
	private String udtRsn;
}
