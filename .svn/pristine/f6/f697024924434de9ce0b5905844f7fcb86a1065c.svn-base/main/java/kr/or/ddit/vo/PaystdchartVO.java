package kr.or.ddit.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PaystdchartVO {
	private int jobWageAmt;
	private int ptnWageMt;
	private int grdWageAdd;
	private int dutyBnf;
	private int fex;
	private int etcBnf;
}
