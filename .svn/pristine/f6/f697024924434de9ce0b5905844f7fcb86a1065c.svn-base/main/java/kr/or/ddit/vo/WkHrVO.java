package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class WkHrVO {
	private Date waDate;
	private String empNo;
	private String whStime;
	private String whEtime;
	private String whType;
	private int whTltime;
}
