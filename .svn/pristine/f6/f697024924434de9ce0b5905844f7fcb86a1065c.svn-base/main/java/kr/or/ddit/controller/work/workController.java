package kr.or.ddit.controller.work;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/lhh")
@Controller
public class workController {

	@GetMapping("/work")
	public String work() {
		return "work/work";
	}
	
}
