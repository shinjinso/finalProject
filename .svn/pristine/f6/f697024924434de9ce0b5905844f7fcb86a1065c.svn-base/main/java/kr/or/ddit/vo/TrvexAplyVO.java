package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TrvexAplyVO {
	private String dftNo;
	private String trvRgn;
	private Date trvSdate;
	private Date trvEdate;
	private String trvObj;
	private int dmAmt;
}
