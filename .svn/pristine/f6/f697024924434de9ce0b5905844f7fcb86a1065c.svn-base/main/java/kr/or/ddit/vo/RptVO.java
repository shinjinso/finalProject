package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RptVO {
	private String dftNo;
	private Date rptSdate;
	private Date rptEdate;
	private String rptCont;
}
