package kr.or.ddit.personnel.service;

import java.util.List;

import kr.or.ddit.vo.EmpVO;

public interface MemberService {
	//메소드 시그니처
	
	//회원정보 가져오기
	public EmpVO read(String empNo);
	
	//전체 회원 정보 가져오기
	public List<EmpVO> memberList();
	
}
