package kr.or.ddit.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class AccaVO {
	private int accaNo;
	private String empNo;
	private String acClf;
	private String acNm;
	private Date acEtdate;
	private Date acEdate;
	private String gradClf;
	private String maj;
}
