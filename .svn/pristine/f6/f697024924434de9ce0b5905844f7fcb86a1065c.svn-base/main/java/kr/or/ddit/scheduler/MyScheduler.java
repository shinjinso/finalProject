package kr.or.ddit.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MyScheduler {
//	@Scheduled(fixedDelay = 3000) //3초마다 강혁이 미움!
//	public void gangHate() {
//		log.debug("강혁이 정말 미웡! 밉당!");
//	}
//					 //초  분시간일 월 요일
//	@Scheduled(cron = "10 37 * * * *") //시계로 10초가 되면 이거 실행해라
//	public void gangHate2() {
//		log.debug("강혁이 정말 미웡! 37분 10초에 밉당!");
//	}
}
