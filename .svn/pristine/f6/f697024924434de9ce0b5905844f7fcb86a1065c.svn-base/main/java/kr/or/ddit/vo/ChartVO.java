package kr.or.ddit.vo;

import java.util.List;

import lombok.Data;

@Data
public class ChartVO {
	private String[] labels = {"Jan16", "Feb2", "Mar3", "Apr4", "May", "Jun", "Jul", "Aug", "Sep"};
	private List<DatasetsVO> datasets;
}
